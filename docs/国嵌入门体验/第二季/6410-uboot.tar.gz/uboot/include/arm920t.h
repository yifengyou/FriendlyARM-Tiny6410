/************************************************
 * NAME	    : arm920t.h
 * Version  : 30 April 2002			*
 *
 * empty for now
 ************************************************/

#ifndef __ARM920T_H__
#define __ARM920T_H__


#endif /*__ARM920T_H__*/
